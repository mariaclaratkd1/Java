package ModuloPagamento;

public class FormasDePagamento {

public float Pix;
public float Debito;
public float Credito;
public float Boleto;

public FormasDePagamento(float pix, float debito, float credito, float boleto) {
Pix = pix;
Debito = debito;
Credito = credito;
Boleto = boleto;
}

public float getPix() {
return Pix;
}
public void setPix(float pix) {
Pix = pix;
}

public float getDebito() {
return Debito;
}
public void setDebito(float debito) {
Debito = debito;
}

public float getCredito() {
return Credito;
}
public void setCredito(float credito) {
Credito = credito;
}

public float getBoleto() {
return Boleto;
}
public void setBoleto(float boleto) {
Boleto = boleto;
}

}

