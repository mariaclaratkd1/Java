package ModuloCliente;

public class Cliente {
    private String nome;
    private String cpf;
    private String email;

    public Cliente(String nome, String cpf, String email) {
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
    }

    public String getNome() { return nome; }
    public String getCPF() { return cpf; }
    public String getEmail() { return email; }

    public void setNome(String nome) { this.nome = nome; }
    public void setCPF(String cpf) { this.cpf = cpf; }
    public void setEmail(String email) { this.email = email; }
}
