package ModuloVendas;

import java.util.Scanner;
import ModuloCliente.Cliente;
import java.util.ArrayList;
import ModuloProduto.Produto;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);  
       
        ArrayList<Cliente> ListaCliente = new ArrayList<>();
        ArrayList<Produto> ListaProduto = new ArrayList<>();
        ArrayList<Vendedor> ListaVendedores = new ArrayList<>();
        ArrayList<SupervisorVendas> ListaSupervisorVendas = new ArrayList<>();

        System.out.print("Quantos Clientes deseja cadastrar? ");
        int numClientes = sc.nextInt();
        sc.nextLine();

        for (int i = 0; i < numClientes; i++) {
            System.out.println("\n----- CLIENTE " + (i+1) + " -----");
            System.out.print("Nome: ");
            String nomeCliente = sc.nextLine();
            System.out.print("CPF: ");
            String cpfCliente = sc.nextLine();
            System.out.print("Email: ");
            String emailCliente = sc.nextLine();

            Cliente cliente = new Cliente(nomeCliente, cpfCliente, emailCliente);
            ListaCliente.add(cliente);
        }

        System.out.print("\nQuantos Produtos deseja cadastrar? ");
        int numProdutos = sc.nextInt();
        sc.nextLine(); 

        for (int l = 0; l < numProdutos; l++) {
            System.out.println("\n----- Produto " + (l + 1) + " -----");

            System.out.print("ID do Produto: ");
            int idProduto = sc.nextInt();
            sc.nextLine();

            System.out.print("Nome do Produto: ");
            String nome = sc.nextLine();

            System.out.print("Preço do Produto: ");
            float preco = sc.nextFloat();
            sc.nextLine(); 

            Produto produto = new Produto(idProduto, nome, preco);
            ListaProduto.add(produto);
        }

        System.out.print("\nQuantos Vendedores deseja cadastrar? ");
        int numVendedores = sc.nextInt();
        sc.nextLine(); 

        for (int j = 0; j < numVendedores; j++) {
            System.out.println("\n----- VENDEDOR " + (j+1) + " -----");
            System.out.print("Nome do Vendedor: ");
            String nomeVendedor = sc.nextLine();
            System.out.print("Salário do Vendedor: ");
            double salarioVendedor = sc.nextDouble();
            sc.nextLine(); 

            Vendedor vendedor = new Vendedor(nomeVendedor, salarioVendedor);
            ListaVendedores.add(vendedor);
        }

        System.out.print("\nQuantos Supervisores deseja cadastrar? ");
        int numSupervisorVendas = sc.nextInt();
        sc.nextLine(); 

        for (int k = 0; k < numSupervisorVendas; k++) {
            System.out.println("\n----- SUPERVISOR " + (k+1) + " -----");
            System.out.print("Nome do Supervisor: ");
            String nomeSupervisor = sc.nextLine();
            System.out.print("Salário do Supervisor: ");
            double salarioSupervisor = sc.nextDouble();
            System.out.print("Idade do Supervisor: ");
            int idadeSupervisor = sc.nextInt();
            sc.nextLine(); 

            SupervisorVendas supervisor = new SupervisorVendas(nomeSupervisor, salarioSupervisor, idadeSupervisor);
            ListaSupervisorVendas.add(supervisor);
        }

        int opcao;
        do {
            System.out.println("\n===== Menu de Pagamento =====");
            System.out.println("Escolha a forma de pagamento:");
            System.out.println("1 - Pix");
            System.out.println("2 - Débito");
            System.out.println("3 - Crédito");
            System.out.println("4 - Boleto");
            System.out.println("0 - Cancelar");
            System.out.print("Opção: ");
            opcao = sc.nextInt();
            sc.nextLine(); 

            String formaEscolhida = "";
            switch (opcao) {
                case 1 -> formaEscolhida = "Pix";
                case 2 -> formaEscolhida = "Débito";
                case 3 -> formaEscolhida = "Crédito";
                case 4 -> formaEscolhida = "Boleto";
                case 0 -> {
                    System.out.println("Operação cancelada.");
                    continue;
                }
                default -> {
                    System.out.println("Opção inválida. Tente novamente.");
                    continue;
                }
            }

            System.out.print("Informe o valor a ser pago em " + formaEscolhida + ": R$ ");
            float valorPagamento = sc.nextFloat();
            sc.nextLine(); 

            System.out.println("\n===== Confirmação =====");
            System.out.println("Forma de pagamento escolhida: " + formaEscolhida);
            System.out.printf("Valor: R$ %.2f%n", valorPagamento);
            System.out.print("Deseja confirmar o pagamento? (S/N): ");
            String confirmar = sc.nextLine();

            if (confirmar.equalsIgnoreCase("S")) {
                System.out.println("Pagamento confirmado com sucesso!");
                break;
            } else {
                System.out.println("Pagamento cancelado. Voltando ao menu...");
            }

        } while (opcao != 0);

        sc.close();
    }
}