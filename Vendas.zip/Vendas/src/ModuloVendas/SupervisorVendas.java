package ModuloVendas;

public class SupervisorVendas extends Vendedor {
    private int idade;

    public SupervisorVendas(String nome, double salario, int idade) {
        super(nome, salario);
        this.idade = idade;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public void vender (String produto) {
        System.out.println("Supervisor vendeu o produto: " + produto);
    }
}
