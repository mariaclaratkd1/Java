package Cursos;
public class Main1 {
    public static void main(String[] args) {
        // Criando alunos
        Aluno aluno1 = new Aluno("Carlos Silva", "A001", 20);
        Aluno aluno2 = new Aluno("Maria Oliveira", "A002", 22);

        // Criando cursos
        Curso curso1 = new Curso("Engenharia de Software", "ES101", 3000);
        Curso curso2 = new Curso("Ciência da Computação", "CC102", 3200);

        // Criando matrículas
        Matricula matricula1 = new Matricula(aluno1, curso1, 2025, 1);
        Matricula matricula2 = new Matricula(aluno2, curso2, 2025, 2);

        // Exibindo matrículas
        System.out.println("=== Matrícula 1 ===");
        matricula1.exibirMatricula();

        System.out.println("\n=== Matrícula 2 ===");
        matricula2.exibirMatricula();
    }
}
