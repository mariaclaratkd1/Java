package Cursos;
public class Matricula {
        private Aluno aluno;
        private Curso curso;
        private int ano;
        private int semestre;

        public Matricula(Aluno aluno, Curso curso, int ano, int semestre) {
            this.aluno = aluno;
            this.curso = curso;
            this.ano = ano;
            this.semestre = semestre;
        }

        public void exibirMatricula() {
            System.out.println("Aluno: " + aluno.getNome() + " (Matrícula: " + aluno.getMatricula() + ", Idade: " + aluno.getIdade() + ")");
            System.out.println("Curso: " + curso.getNome() + " (Código: " + curso.getCodigo() + ", Carga Horária: " + curso.getCargaHoraria() + "h)");
            System.out.println("Ano: " + ano + ", Semestre: " + semestre);
        }
}